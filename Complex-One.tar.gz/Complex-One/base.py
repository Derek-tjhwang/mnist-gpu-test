#! /usr/bin/env python

from __future__ import print_function

import os, sys
import tensorflow as tf
from functools import partial

class Model_MNIST(object):
	def __init__(self, params=None):
		if params is None:
			print('Trainning Network\'s parameters not defined.')
		else:
			self._init_architechture(**params)
		tf.reset_default_graph()
		self.sess = None
		self.X = tf.placeholder(tf.float32, shape=[None, 784], name='X')
		self.Y = tf.placeholder(tf.int32, shape=[None], name='Y')
		self._build_graph()
	
	def _init_architechture(self, export_path, version, 
								learning_rate, keep_prob, use_gpu):
		self.export_path_base = export_path
		self.version = version
		self.learning_rate = learning_rate
		self.keep_prob = keep_prob
		self.use_gpu = use_gpu
		self.serialized_tf_input = tf.placeholder(tf.string, name='tf_input')
	
	def _export_model(self):
		export_path = os.path.join(
			tf.compat.as_bytes(self.export_path_base),
			tf.compat.as_bytes(str(self.version)))
		builder = tf.saved_model.builder.SavedModelBuilder(export_path)
		classification_inputs = tf.saved_model.utils.build_tensor_info(self.X)
		classification_classes = tf.saved_model.utils.build_tensor_info(self.prediction_classes )
		classification_scores = tf.saved_model.utils.build_tensor_info(self.values)

		classification_signature = (
			tf.saved_model.signature_def_utils.build_signature_def(
				inputs={tf.saved_model.signature_constants.CLASSIFY_INPUTS:classification_inputs},
				outputs={tf.saved_model.signature_constants.CLASSIFY_OUTPUT_CLASSES:classification_classes,
						tf.saved_model.signature_constants.CLASSIFY_OUTPUT_SCORES:classification_scores},
				method_name=tf.saved_model.signature_constants.CLASSIFY_METHOD_NAME))
		tensor_info_x = tf.saved_model.utils.build_tensor_info(self.X)
		tensor_info_y = tf.saved_model.utils.build_tensor_info(self.y_prob)

		prediction_signature = (
			tf.saved_model.signature_def_utils.build_signature_def(
			inputs={'images': tensor_info_x},
			outputs={'scores': tensor_info_y},
			method_name=tf.saved_model.signature_constants.PREDICT_METHOD_NAME))

		builder.add_meta_graph_and_variables(
			self.sess, [tf.saved_model.tag_constants.SERVING],
			signature_def_map={
				'predict_images': prediction_signature,
				tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY: classification_signature,
				},
				main_op=tf.tables_initializer(), strip_default_attrs=True)

		builder.save()
		print('Model Base Export Complete. Path : {}'.format(str(export_path)))

	def _build_graph(self):
		with tf.variable_scope('init'):
			self.is_training = tf.placeholder_with_default(False, shape=(), name='training')
		with tf.variable_scope('network'):
			self._define_network()
			self.y_prob = tf.nn.softmax(self.logits)
			self._optimization()
		with tf.variable_scope('inference'):
			self.values, self.indices = tf.nn.top_k(self.logits, 10)
			table = tf.contrib.lookup.index_to_string_table_from_tensor(tf.constant([str(i) for i in range(10)]))
			self.prediction_classes = table.lookup(tf.to_int64(self.indices))
	
	def _define_network(self):
		initializer = tf.contrib.layers.variance_scaling_initializer()
		dense_layer = partial(tf.layers.dense, kernel_initializer=initializer)
		classify_layer = dense_layer(self.X, 784, activation=tf.nn.elu)
		self.logits = dense_layer(classify_layer, 10, activation=None)
		xentropy = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=self.Y, logits=self.logits)
		self.classify_loss = tf.reduce_mean(xentropy)
	
	def _optimization(self):
		self.optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
		self.training_op = self.optimizer.minimize(self.classify_loss)
	
	def fit(self, X_batches, Y_batches, epoches, n_batch):
		config = tf.ConfigProto()
		config.gpu_options.per_process_gpu_memory_fraction = 1
		self.sess = tf.Session(config=config)
		self.sess.run(tf.global_variables_initializer())
		for epoch in range(epoches):
			for iteration in range(n_batch):
				print('\r{}%'.format(100 * iteration // n_batch), end='')
				sys.stdout.flush()
				X_batch = X_batches[iteration]
				Y_batch = Y_batches[iteration]
				feed_dict={self.X: X_batch, self.Y: Y_batch, self.is_training: True}
				_, cost = self.sess.run([self.training_op, self.classify_loss], feed_dict=feed_dict)
			print('\rTrain epoch {0} complete. Loss Cost : {1}'.format(epoch+1, cost))
		self._export_model()


