#! /usr/bin/env python

from __future__ import print_function

import os, sys, pickle
import numpy as np
import tensorflow as tf
from functools import partial
from datetime import datetime

from base import Model_MNIST

def pickle_load(filename):
	with open(filename, 'rb') as dump_file:
		dataset = pickle.load(dump_file)
	return dataset

'''
Test Model #3 - Convolutional Neural Network
'''
class CNN(Model_MNIST):
	def __init__(self, params):
		super(CNN, self).__init__(params)

	def _define_network(self):
		with tf.device('/cpu:0'):
			initializer = tf.contrib.layers.xavier_initializer()
			dense_layer = partial(tf.layers.dense, kernel_initializer=initializer)
			height = 28
			width = 28
			channels = 1
			conv1_fmaps = 32
			conv1_ksize = 3
			conv1_stride = 1
			conv1_pad = "SAME"

			conv2_fmaps = 64
			conv2_ksize = 3
			conv2_stride = 1
			conv2_pad = "SAME"
			conv2_dropout_rate = 0.25

			pool_fmaps = conv2_fmaps

			fc_dropout_rate = 0.5
			batch_size = int(128 / self.use_gpu)

			losses = []

			for i in range(self.use_gpu):
				with tf.device(tf.DeviceSpec(device_type="GPU", device_index=i)):
					with tf.variable_scope(tf.get_variable_scope(), reuse=i>0):
						_x = self.X[i * batch_size: (i+1) * batch_size]
						_y = self.Y[i * batch_size: (i+1) * batch_size]

						with tf.name_scope("inputs"):
							X_reshaped = tf.reshape(_x, shape=[-1, height, width, channels])
						with tf.name_scope("convolution"):
							conv1 = tf.layers.conv2d(X_reshaped, filters=conv1_fmaps, kernel_size=conv1_ksize,
													 strides=conv1_stride, padding=conv1_pad,
													 activation=tf.nn.relu, name="conv1")
							conv2 = tf.layers.conv2d(conv1, filters=conv2_fmaps, kernel_size=conv2_ksize,
													 strides=conv2_stride, padding=conv2_pad,
													 activation=tf.nn.relu, name="conv2")
						with tf.name_scope("pool"):
							pool = tf.nn.max_pool(conv2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding="VALID")
							pool_flat = tf.reshape(pool, shape=[-1, pool_fmaps * 14 * 14])
							pool_flat_drop = tf.layers.dropout(pool_flat, conv2_dropout_rate, training=self.is_training)
						with tf.name_scope("fully-connection"):
							classify_layer = tf.layers.dense(pool_flat_drop, 128, activation=tf.nn.relu, name="fully")
							classify_layer = tf.layers.dropout(classify_layer, fc_dropout_rate, training=self.is_training)
							self.logits = dense_layer(classify_layer, 10, activation=None)
						with tf.name_scope("loss"):
							xentropy = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=_y, logits=self.logits)
							losses.append(xentropy)

			self.classify_loss = tf.reduce_mean(tf.concat(losses, axis=0))


if __name__ == '__main__':
	start_time = datetime.now()
	if len(sys.argv) < 2:
		print('Using : python main.py $export_dir')
		sys.exit(-1)
	ngpus = int(sys.argv[2]) if '--gpus' in sys.argv else 0
	export_path_base = sys.argv[-1]
	data_path = '{}/data'.format(os.getcwd())
	filename = data_path + '/X_batches.pkl'
	X_batches = pickle_load(filename)
	print('X_batches : {}'.format(np.array(X_batches).shape))
	filename = data_path + '/Y_batches.pkl'
	Y_batches = pickle_load(filename)
	print('Y_batches : {}'.format(np.array(Y_batches).shape))
	
	params = dict(
		export_path=export_path_base ,
		version=1,
		learning_rate=1e-2,
		keep_prob=0.6,
		use_gpu=ngpus)

	model = CNN(params)
	model.fit(X_batches, Y_batches, 100, 128)
	end_time = datetime.now()
	duration = end_time - start_time
	pStr = "StartTime: {}, EndTime: {}, Duration: {}".format(start_time, end_time, duration)
	strLen = len(pStr)
	print("=" * strLen)
	print(pStr)
	print("=" * strLen)

