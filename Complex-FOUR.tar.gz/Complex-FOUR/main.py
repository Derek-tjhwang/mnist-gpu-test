#! /usr/bin/env python

from __future__ import print_function

import os, sys, pickle
import numpy as np
import tensorflow as tf
from functools import partial
from datetime import datetime

from base import Model_MNIST

def pickle_load(filename):
	with open(filename, 'rb') as dump_file:
		dataset = pickle.load(dump_file)
	return dataset

'''
Test Model #3 - Convolutional Neural Network
'''


class CNN(Model_MNIST):
	def __init__(self, params):
		super(CNN, self).__init__(params)

	def average_gradients(self, tower_grads):
		average_grads = []
		for grad_and_vars in zip(*tower_grads):
			# Note that each grad_and_vars looks like the following:
			#   ((grad0_gpu0, var0_gpu0), ... , (grad0_gpuN, var0_gpuN))
			grads = []
			for g, _ in grad_and_vars:
				# Add 0 dimension to the gradients to represent the tower.
				expanded_g = tf.expand_dims(g, 0)

				# Append on a 'tower' dimension which we will average over below.
				grads.append(expanded_g)

			# Average over the 'tower' dimension.
			grad = tf.concat(grads, 0)
			grad = tf.reduce_mean(grad, 0)

			# Keep in mind that the Variables are redundant because they are shared
			# across towers. So .. we will just return the first tower's pointer to
			# the Variable.
			v = grad_and_vars[0][1]
			grad_and_var = (grad, v)
			average_grads.append(grad_and_var)
		return average_grads

	def _define_network(self):
		initializer = tf.contrib.layers.xavier_initializer()
		dense_layer = partial(tf.layers.dense, kernel_initializer=initializer)
		height = 28
		width = 28
		channels = 1
		conv1_fmaps = 32
		conv1_ksize = 3
		conv1_stride = 1
		conv1_pad = "SAME"

		conv2_fmaps = 64
		conv2_ksize = 3
		conv2_stride = 1
		conv2_pad = "SAME"
		conv2_dropout_rate = 0.25

		pool_fmaps = conv2_fmaps

		fc_dropout_rate = 0.5

		batch_size = int(128 / self.use_gpu)

		tower_grads = []
		for d in range(self.use_gpu):
			with tf.device('/device:GPU:%d' % d):
				with tf.variable_scope(tf.get_variable_scope(), reuse=(d > 0)):
					_x = self.X[batch_size * d:batch_size * (d + 1)]
					_y = self.Y[batch_size * d:batch_size * (d + 1)]

					with tf.name_scope('tower_%d' % d) as scope:
						X_reshaped = tf.reshape(_x, shape=[-1, height, width, channels])
						conv1 = tf.layers.conv2d(X_reshaped, filters=conv1_fmaps, kernel_size=conv1_ksize,
												 strides=conv1_stride, padding=conv1_pad,
												 activation=tf.nn.relu, name="conv1")
						conv2 = tf.layers.conv2d(conv1, filters=conv2_fmaps, kernel_size=conv2_ksize,
												 strides=conv2_stride, padding=conv2_pad,
												 activation=tf.nn.relu, name="conv2")
						pool = tf.nn.max_pool(conv2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding="VALID")
						pool_flat = tf.reshape(pool, shape=[-1, pool_fmaps * 14 * 14])
						pool_flat_drop = tf.layers.dropout(pool_flat, conv2_dropout_rate, training=self.is_training)
						classify_layer = tf.layers.dense(pool_flat_drop, 128, activation=tf.nn.relu, name="fully")
						classify_layer = tf.layers.dropout(classify_layer, fc_dropout_rate, training=self.is_training)
						self.logits = dense_layer(classify_layer, 10, activation=None)

						xentropy = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=_y, logits=self.logits)
						self.classify_loss = tf.reduce_mean(xentropy)

						self.optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
						grads = self.optimizer.compute_gradients(self.classify_loss)
						tower_grads.append(grads)

		self.tower_grads = self.average_gradients(tower_grads)
		self.training_op = self.optimizer.apply_gradients(self.tower_grads)


if __name__ == '__main__':
	start_time = datetime.now()
	if len(sys.argv) < 2:
		print('Using : python main.py $export_dir')
		sys.exit(-1)
	ngpus = 4
	export_path_base = sys.argv[-1]
	data_path = '{}/data'.format(os.getcwd())
	filename = data_path + '/X_batches.pkl'
	X_batches = pickle_load(filename)
	print('X_batches : {}'.format(np.array(X_batches).shape))
	filename = data_path + '/Y_batches.pkl'
	Y_batches = pickle_load(filename)
	print('Y_batches : {}'.format(np.array(Y_batches).shape))
	
	params = dict(
		export_path=export_path_base ,
		version=1,
		learning_rate=1e-2,
		keep_prob=0.6,
		use_gpu=ngpus)

	model = CNN(params)
	model.fit(X_batches, Y_batches, 100, 128)
	end_time = datetime.now()
	duration = end_time - start_time
	pStr = "StartTime: {}, EndTime: {}, Duration: {}".format(start_time, end_time, duration)
	strLen = len(pStr)
	print("=" * strLen)
	print(pStr)
	print("=" * strLen)

